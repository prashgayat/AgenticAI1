# utils/ranker.py

from openai import OpenAI
from openai import OpenAIError
import os
from datetime import datetime
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def score_and_rank_jobs(jobs, keywords):
    if not jobs:
        print("⚠️ No jobs provided to score.")
        return []

    print(f"📊 Ranking {len(jobs)} job(s)...")

    # Convert keywords to string for vectorization
    query_text = " ".join(keywords).lower()

    # Prepare job texts
    job_texts = [f"{job['title']} {job['description']}".lower() for job in jobs]

    # TF-IDF vectorization
    vectorizer = TfidfVectorizer().fit([query_text] + job_texts)
    query_vec = vectorizer.transform([query_text])
    job_vecs = vectorizer.transform(job_texts)

    # Compute cosine similarity (keyword match)
    cosine_scores = cosine_similarity(query_vec, job_vecs)[0]

    ranked = []
    for idx, job in enumerate(jobs):
        score = float(cosine_scores[idx])
        # Use 1 - cosine for semantic "distance"
        distance = 1 - score

        # Attach additional metadata
        ranked.append({
            "title": job["title"],
            "description": job["description"],
            "job_link": job["url"],  # normalize naming
            "job_title": job["title"],  # normalized for downstream tools
            "score": round(score, 4),
            "distance": round(distance, 4),
            "timestamp": datetime.utcnow().isoformat()
        })

    # Sort by best score (higher score = better match)
    ranked = sorted(ranked, key=lambda x: x["score"], reverse=True)

    print(f"✅ Ranked {len(ranked)} jobs.")
    return ranked

# tools.py

from langchain.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Type, Optional, List
import json
import csv
import os

# === 1. Job Search Tool ===

class JobSearchInput(BaseModel):
    keywords: Optional[str] = Field(default=None, description="Search keywords for job retrieval")

class JobSearchTool(BaseTool):
    name: str = "Job Search Tool"
    description: str = "Search for relevant jobs based on keyword relevance and semantic distance"
    args_schema: Type[BaseModel] = JobSearchInput

    def _run(self, keywords: Optional[str] = None):
        from scraper import run_scraper
        from utils.ranker import score_and_rank_jobs

        if isinstance(keywords, str):
            keywords = [k.strip() for k in keywords.split(",")]

        raw_jobs = run_scraper(keywords)
        ranked_jobs = score_and_rank_jobs(raw_jobs, keywords)

        if not ranked_jobs:
            return "No relevant jobs found."

        formatted = "\n\n".join(
            f"Title: {job['job_title']}\nScore: {job['score']:.2f}\nLink: {job['job_link']}\nDesc: {job['description'][:200]}..."
            for job in ranked_jobs
        )
        return formatted

# === 2. Job Evaluator Tool ===

class JobEvaluatorInput(BaseModel):
    job: str = Field(..., description="Job description to evaluate")
    score: float = Field(..., description="Keyword match score (0 to 1)")
    distance: float = Field(..., description="Semantic distance (lower is better)")

class JobEvaluatorTool(BaseTool):
    name: str = "Job Evaluator Tool"
    description: str = "Evaluates the job relevance using semantic and keyword match score"
    args_schema: Type[BaseModel] = JobEvaluatorInput

    def _run(self, job: str, score: float, distance: float):
        relevance = score * (1.0 - distance)
        return f"Relevance Score: {relevance:.2f}\nJob Summary: {job}"

# === 3. Proposal Writer Tool ===

class ProposalInput(BaseModel):
    job_title: str = Field(..., description="Title of the job")
    job_description: str = Field(..., description="Job description")

class ProposalTool(BaseTool):
    name: str = "Proposal Writer Tool"
    description: str = "Writes a proposal for a given job title and description"
    args_schema: Type[BaseModel] = ProposalInput

    def _run(self, job_title: str, job_description: str):
        return f"""Dear Client,

I am excited to apply for the {job_title}. With experience in similar projects, I believe I can deliver exceptional results tailored to your needs. My approach is solution-oriented and client-focused.

Let's connect to discuss your goals in more detail.

Best regards,
Gayatri"""

# === 4. Memory Logger Tool ===

class MemoryInput(BaseModel):
    job_title: str = Field(..., description="Job title")
    job_link: str = Field(..., description="Job application URL")
    proposal: str = Field(..., description="Proposal text")
    application_status: str = Field(default="applied", description="Application status (e.g., 'applied')")

class MemoryTool(BaseTool):
    name: str = "Memory Logger Tool"
    description: str = "Logs applied jobs and proposals for record keeping"
    args_schema: Type[BaseModel] = MemoryInput

    def _run(self, job_title: str, job_link: str, proposal: str, application_status: str = "applied"):
        os.makedirs("memory", exist_ok=True)

        json_entry = {
            "job_title": job_title,
            "job_link": job_link,
            "proposal": proposal,
            "status": application_status
        }

        json_path = "memory/memory_log.json"
        csv_path = "memory/memory_log.csv"

        # Append to JSON
        if os.path.exists(json_path):
            with open(json_path, "r") as f:
                data = json.load(f)
        else:
            data = []

        data.append(json_entry)
        with open(json_path, "w") as f:
            json.dump(data, f, indent=2)

        # Append to CSV
        write_header = not os.path.exists(csv_path)
        with open(csv_path, "a", newline='', encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["job_title", "job_link", "proposal", "status"])
            if write_header:
                writer.writeheader()
            writer.writerow(json_entry)

        return f"Logged job '{job_title}' with status '{application_status}'."
